# Meu Projeto Backend

## Requisitos
- Python 3.10+
- Docker (opcional)

## Como rodar

```bash
cp .env.example .env
uvicorn app.main:app --reload
```

Ou com Docker:
```bash
docker-compose up --build
```
